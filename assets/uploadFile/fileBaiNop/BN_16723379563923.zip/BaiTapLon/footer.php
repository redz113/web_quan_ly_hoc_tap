<footer class="card-footer mb-0" style="background: rgba(0, 0, 0, 0.2); text-align: center;">
		<div class="container w-75">
			<div class="row" style="justify-content: center; align-items: center;">
				<div class="col-0 col-lg-1"><img src="assets/image/logoIT.png" style="max-width: 80px;" width="100%" height="auto" alt="IT-HNUE"></div>
				<div class="col-12 col-lg-4">
					Nhóm 2 K70 Công nghệ Web <br>
					Khoa Công Nghệ Thông Tin - ĐHSPHN
				</div>
			</div>
		</div>
	<p class="my-3" style="font-size: 1.2rem;">All rights reserved by © Khoa Công nghệ thông tin - ĐHSPHN 2022</p>
</footer>