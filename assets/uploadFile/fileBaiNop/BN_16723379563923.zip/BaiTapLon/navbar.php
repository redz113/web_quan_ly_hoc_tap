<style type="text/css">
	.navbar .text-nav:hover{
		text-shadow: 0px 2px 2px red;
		transform: translateY(-1px) translateX(1px);
		transition: font-size 0.1s;
	}
</style>


<nav class="navbar navbar-expand-lg text-uppercase fixed-top bg-success" id="mainNav">
        <div class="container-fluid">
            	<a class="navbar-brand px-3" href="KhoaHoc.php">
					<img width="200px" height="60px" src="assets/image/logoA.png">
	            </a>
            <button class="navbar-toggler text-uppercase font-weight-bold bg-inverse border-dark text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <!-- <i class="fas fa-bars"></i> -->
                <img src="./assets/image/menu.png">
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto" style="font-size: 18px;">
			    	<li class="nav-item dropdown">
					  <a class="text-nav nav-link active py-3 px-0 px-lg-3 rounded text-white" href="KhoaHoc.php"><img class="p-1" src="assets/image/stack.png">Khóa học</a>
					</li>

					<!-- <li class="nav-item dropdown">
					  <a class="text-nav nav-link active py-3 px-0 px-lg-3 rounded text-white" href="#" ><img class="p-1" src="assets/image/bookmark.png">Bài tập</a>
					</li> -->

				<?php 
				// if (!isset($_SESSION['user'])) {
				?>

					<!-- <li class="nav-item dropdown text-white">
					  <a class="text-nav nav-link active py-3 px-0 px-lg-1 rounded text-white" style="display: inline-block;" href="DangKy.php" >Đăng ký</a> 
					  				|
					  <a class="text-nav nav-link active py-3 px-0 px-lg-1 rounded text-white" style="display: inline-block;" href="DangNhap.php" >Đăng nhập</a>
					</li> -->
				<?php /*}else{ */
						$row = selectTK($_SESSION['user']);
					?>


					<li class="nav-item dropdown">
					  <a class="text-nav nav-link dropdown-toggle active py-3 px-0 px-lg-3 rounded text-white" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
					    <?php 
					    	echo "<img class='p-1' src='assets/image/user.png'>" .$row['ten_hien_thi'];
					    ?>
					  </a>
					  <ul class="dropdown-menu" style="position: absolute;left: 20px;" aria-labelledby="navbarDropdownMenuLink">
					  	<li><a class="text-nav dropdown-item py-2" href="#">Admin Setting</a></li>
					  	<li><a class="text-nav dropdown-item py-2" href="#">Danh sách điểm số</a></li>
					  	<li><a class="text-nav dropdown-item py-2" href="DoiMatKhau.php">Đổi mật khẩu</a></li>
					    <li><a class="text-nav dropdown-item py-2" href="DangXuat.php">Đăng xuất</a></li>
					  </ul>
					</li>

				<?php 
					// }; 
				?>
				</ul>


            </div>
        </div>
    </nav>

<?php 
	// function 
?>