<?php 
	include "./Connect.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Đăng Ký</title>
	<link rel="stylesheet" type="text/css" href="./assets/cssX/style1.css">
	<!-- <style type="text/css">
		
	</style> -->
</head>
<body>
	<?php 
		$flag = 0;

		if (isset($_POST['submit'])) {
			$fullname = $_POST['fullname'];
			$user = $_POST['username'];
			$pass = $_POST['password'];
			$cfpass = $_POST['cfpassword'];

			$kq = check_dangky($user, $pass, $cfpass);
			if ($kq == "") {
				$flag = 1;
			}else echo "<div class = 'check'> $kq </div>";
		}

		if ($flag == 1) {
			if (!check_userdb($user)) {
				$sql_insert = "INSERT INTO tb_tai_khoan VALUES('$user', '$fullname', '$pass', '')";
				mysqli_query($conn, $sql_insert);
				echo "<div class = 'check'> Đăng Ký Thành Công </div>";
			}else echo "<div class = 'check'> User Name đã tồn tại </div>";
		}
	?>
	<div class="main">
		<div class="content">
			<div class="title">Đăng Ký</div>
			<div class="form">
				<form method="post" action="">
					<div class="input-1">
						<label for="ip-fn">Full Name</label>
						<input type="text" name="fullname" id="ip-fn" placeholder="Fullname..." value="<?php if(isset($fullname)) echo $fullname; else echo ""; ?>" >
					</div>
					<div class="input-1">
						<label for="ip-un">User Name</label>
						<input type="text" name="username" id="ip-un" placeholder="Username..." value="<?php if(isset($user)) echo $user; else echo ""; ?>">
					</div>
					<div class="input-1">
						<label for="ip-pw">Password</label>
						<input type="password" name="password" id="ip-pw" placeholder="Password..." value="<?php if(isset($pass)) echo $pass; else echo ""; ?>">
					</div>
					<div class="input-1">
						<label for="ip-cfpw">Confirm Password</label>
						<input type="password" name="cfpassword" id="ip-cfpw" placeholder="Confirm password..." value="<?php if(isset($cfpass)) echo $cfpass; else echo ""; ?>">
					</div>
					<div style="height: 12px;"></div>
					
					<input class="btn-submit" type="submit" name="submit" value="Đăng Ký">
					
				</form>
				<div class="link">
					<a href="DangNhap.php">Đăng nhập tài khoản</a>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</body>
</html>

<?php 
	// function check_dangky($user, $pass, $cfpass){
	// 	if (empty($user) || empty($pass) || empty($cfpass)) {
	// 		return "Bạn cần nhập đầy đủ thông tin";
	// 	}else{
	// 		$check = check_str("User Name",$user) .check_str("Password", $pass) .check_cfpass($pass, $cfpass);
	// 	}

	// 	return $check;
	// }

	// function check_str($str, $value){
	// 	$kq = "";
	// 	if (strlen($value) < 6 && strlen($value) > 0) {
	// 		$kq .= "$str phải có độ dài >= 6 ký tự <br>";
	// 	}

	// 	if (strpos($value, " ") == true) {
	// 		$kq .= "$str không được chứa ký tự khoảng trắng <br>";
	// 	}
	// 	return $kq;
	// }

	// function check_cfpass($pass, $cfpass){
	// 	$kq = "";

	// 	if ($pass != $cfpass) {
	// 		$kq .= "Password và Confirm Password phải trùng nhau <br>";
	// 	}
	// 	return $kq;
	// }

	// function check_userdb($user, $conn){
	// 	$sql_select = "SELECT * FROM tb_tai_khoan WHERE ten_dang_nhap = '$user'";
	// 	$query_sl = mysqli_query($conn, $sql_select);

	// 	if (mysqli_num_rows($query_sl) == 0) {
	// 		return true;	
	// 	}else return false;
	// }
?>