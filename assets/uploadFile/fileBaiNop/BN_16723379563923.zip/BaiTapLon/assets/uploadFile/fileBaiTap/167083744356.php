
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Quản lí bài nộp</title>
	<!-- Begin bootstrap cdn -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="	sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	<!-- End bootstrap cdn -->

</head>
<body>
	<?php include 'navbar.php' ?>

	<main style="min-height: 100vh; max-width: 100%;">
		<div id="action" style="margin: 20px 0 0 13%;">
			<a class="btn btn-primary" href="">Trở lại</a>
		</div>
		<div class="d-flex flex-wrap flex-column align-items-center" style="padding: 1%">

				hiển thị thông tin của tài khoản đang đăng nhập
				
				Hiển thị thông tin của khóa học

			<h4>Danh sách bài nộp:</h4>

			
			<table class="table table-bordered w-75">
				<tr>
					<th>STT</th>
					<th>Tên chủ đề</th>
					<th>Tên bài tập</th>
					<th>File nộp</th>
					<th>Thời gian nộp</th>
					<th>Trạng thái duyệt</th>
				</tr>
				<tr>
					<td>1</td>
					<td>Chủ đề vòng lặp</td>
					<td>Bài 1</td>
					<td>abc.php</td>
					<td>11-12-2022</td>
					<td>
						<span class="btn btn-info">Đạt</span>
					</td>
				</tr>
				<tr>
					<td>2</td>
					<td>Chủ đề vòng lặp</td>
					<td>Bài 2</td>
					<td>abc.php</td>
					<td>11-12-2022</td>
					<td>
						<span class="btn btn-info">Chưa đạt</span>
					</td>
				</tr>
				<tr>
					<td>1</td>
					<td>Chủ đề mảng</td>
					<td>Bài 1</td>
					<td>abc.php</td>
					<td>11-12-2022</td>
					<td>
						<span class="btn btn-info">Chưa duyệt</span>
					</td>
				</tr>
			</table>
			

			

		</div>
	</main>
</body>

	
</html>