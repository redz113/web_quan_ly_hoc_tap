<?php 
	include "Connect.php";

	$idCD = $_GET['idCD'];
	$idKH = $_SESSION['idKH'];

	xoaCDBT($idCD);                                 //120 - function.php
	xoa("tb_chu_de", $idCD);                        //114 - function.php

	echo 
	"
		<script type='text/javascript'>
			alert('Xóa thành công!!!');
		</script>
	";

	header("refresh: 0.3; url =ChuDeKhoaHoc.php?idKH=$idKH");
?>
