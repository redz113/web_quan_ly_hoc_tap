-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 03:23 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_btl_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_bai_nop`
--

CREATE TABLE `tb_bai_nop` (
  `id` int(11) NOT NULL,
  `id_bai_tap` int(11) NOT NULL,
  `ten_tai_khoan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_file_nop` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thoi_gian_nop` datetime NOT NULL DEFAULT current_timestamp(),
  `trang_thai` smallint(6) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_bai_tap`
--

CREATE TABLE `tb_bai_tap` (
  `id` int(11) NOT NULL,
  `id_chu_de` int(11) NOT NULL,
  `ten_bai_tap` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `so_bai_thu` int(11) NOT NULL DEFAULT 1,
  `ngay_mo` datetime NOT NULL DEFAULT current_timestamp(),
  `han_nop` datetime NOT NULL,
  `ten_file_bai_tap` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_hien_thi` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_file_tai_lieu` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_bai_tap`
--

INSERT INTO `tb_bai_tap` (`id`, `id_chu_de`, `ten_bai_tap`, `so_bai_thu`, `ngay_mo`, `han_nop`, `ten_file_bai_tap`, `ten_hien_thi`, `ten_file_tai_lieu`) VALUES
(10, 3, 'UploadFile sử dụng Session', 5, '2022-12-12 16:30:43', '2022-12-19 16:28:00', '1670837443562.pdf', 'thong_ke_bai_nop.php', '167083744356.php'),
(11, 3, 'UploadFile sử dụng Cookie', 2, '2022-12-12 16:31:08', '2022-12-19 16:30:00', '1670837468626.pdf', 'bai5.html', '167083746862.html'),
(12, 4, 'Bài Tập Về Nhà', 2, '2022-12-12 16:31:41', '2022-12-14 16:31:00', '1670837501203.pdf', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tb_chu_de`
--

CREATE TABLE `tb_chu_de` (
  `id` int(11) NOT NULL,
  `id_khoa_hoc` int(11) NOT NULL,
  `ten_chu_de` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_chu_de`
--

INSERT INTO `tb_chu_de` (`id`, `id_khoa_hoc`, `ten_chu_de`) VALUES
(3, 1, 'UploadFile'),
(4, 1, 'Session'),
(5, 1, 'Cookie'),
(6, 1, 'DateTime'),
(11, 2, 'Tài Liệu Môn Học');

-- --------------------------------------------------------

--
-- Table structure for table `tb_khoa_hoc`
--

CREATE TABLE `tb_khoa_hoc` (
  `id_khoa_hoc` int(11) NOT NULL,
  `ten_khoa_hoc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_khoa_hoc`
--

INSERT INTO `tb_khoa_hoc` (`id_khoa_hoc`, `ten_khoa_hoc`, `path_img`) VALUES
(1, 'Công nghệ Web', 'congngheweb.gif'),
(2, 'nền tảng phát triển web', '1670852843831.jpg'),
(3, 'Lập trình hướng đối tượng', 'default.jpg'),
(4, 'Nhập môn công nghệ phần mềm', '1670853178691.gif'),
(5, 'trí tuệ nhân tạo', 'default.jpg'),
(6, 'cơ sở dữ liệu', 'default.jpg'),
(7, 'nền tảng phát triển WEB', '1670853291249.gif');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tai_khoan`
--

CREATE TABLE `tb_tai_khoan` (
  `ten_dang_nhap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_hien_thi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mat_khau` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doi_tuong` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tb_tai_khoan`
--

INSERT INTO `tb_tai_khoan` (`ten_dang_nhap`, `ten_hien_thi`, `mat_khau`, `doi_tuong`) VALUES
('00120202', 'Nguyễn Xuân Tiến', '001202', 0),
('12345678', 'Nguyễn Đức Tài', '123456', 0),
('19112002', 'Lê Thị Linh', '112233', 0),
('705105012', 'Đỗ Nguyên Phương', '123456', 0),
('705105089', 'Đỗ Nguyên Phương', '123456', 0),
('705105090', 'Nguyễn Ngọc Tiệp', '123456', 0),
('705105098', 'Nguyễn Xuân Quý', '001202', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_bai_nop`
--
ALTER TABLE `tb_bai_nop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pk_bai_nop1` (`id_bai_tap`),
  ADD KEY `pk_bai_nop2` (`ten_tai_khoan`);

--
-- Indexes for table `tb_bai_tap`
--
ALTER TABLE `tb_bai_tap`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pk_bai_tap` (`id_chu_de`);

--
-- Indexes for table `tb_chu_de`
--
ALTER TABLE `tb_chu_de`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pk_chu_de` (`id_khoa_hoc`);

--
-- Indexes for table `tb_khoa_hoc`
--
ALTER TABLE `tb_khoa_hoc`
  ADD PRIMARY KEY (`id_khoa_hoc`);

--
-- Indexes for table `tb_tai_khoan`
--
ALTER TABLE `tb_tai_khoan`
  ADD PRIMARY KEY (`ten_dang_nhap`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_bai_nop`
--
ALTER TABLE `tb_bai_nop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_bai_tap`
--
ALTER TABLE `tb_bai_tap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_chu_de`
--
ALTER TABLE `tb_chu_de`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_khoa_hoc`
--
ALTER TABLE `tb_khoa_hoc`
  MODIFY `id_khoa_hoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_bai_nop`
--
ALTER TABLE `tb_bai_nop`
  ADD CONSTRAINT `pk_bai_nop1` FOREIGN KEY (`id_bai_tap`) REFERENCES `tb_bai_tap` (`id`),
  ADD CONSTRAINT `pk_bai_nop2` FOREIGN KEY (`ten_tai_khoan`) REFERENCES `tb_tai_khoan` (`ten_dang_nhap`);

--
-- Constraints for table `tb_bai_tap`
--
ALTER TABLE `tb_bai_tap`
  ADD CONSTRAINT `pk_bai_tap` FOREIGN KEY (`id_chu_de`) REFERENCES `tb_chu_de` (`id`);

--
-- Constraints for table `tb_chu_de`
--
ALTER TABLE `tb_chu_de`
  ADD CONSTRAINT `pk_chu_de` FOREIGN KEY (`id_khoa_hoc`) REFERENCES `tb_khoa_hoc` (`id_khoa_hoc`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
