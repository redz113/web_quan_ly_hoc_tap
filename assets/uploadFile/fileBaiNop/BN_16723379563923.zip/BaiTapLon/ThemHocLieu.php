<?php 
	include 'connect.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Thêm học liệu</title>
	<link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.css">
    <script type="text/javascript" src="assets/bootstrap/js/popper.min.js"></script>
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<?php 
		include 'navbar.php';
	?>
	<div style="height: 86px;"></div>
	<?php
		$idKH=$_SESSION['idKH'];
		$folderHL='';
		$tenFileHL='';
		if (isset($_POST['saveHL'])) {
			$fileHL=$_FILES['file_hoc_lieu'];
			if (empty($fileHL['name'])) {
				$kq='Hãy chọn file học liệu!';
			}
			if (isset($kq)) {
				echo "<div class='check check_error'>$kq</div>";
			}else{
				$extension=strtolower(pathinfo($fileHL['name'], PATHINFO_EXTENSION));
				if ($extension=="pdf") {
					$tenFileHL = floor(microtime(true) * 100) ."." .$extension;
					move_uploaded_file($fileHL['tmp_name'], $folderHL . $tenFileHL);
					echo "Upload file học liệu thành công!";
				}
			}
		}
		if (file_exists($folderHL . $tenFileHL)) {
			echo "<iframe src='".$folderHL.$tenFileHL."' width='100% ' height='100%'></iframe>";
		}

	?>
	<div class="d-flex justify-content-center mt-3">
        <form action="" method="POST" enctype="multipart/form-data" class="w-50">
            <h3>Thêm học liệu</h3>
            <div class="mb-3">
              <label for="file_de_bai" class="form-label">Chọn file học liệu</label>
              <input type="file" class="form-control" id="file_hoc_lieu" name="file_hoc_lieu">
            </div>
            <input type="submit" class="btn btn-success" name="saveHL" value="Lưu">
            <a href="TaiLieuMonHoc.php?idKH=<?php echo $idKH; ?>" class="btn btn-success">Trở lại</a>

        </form>
    </div>

</body>
</html>