<?php 
	include "Connect.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sửa Bài Tập</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.css">
    <script type="text/javascript" src="assets/bootstrap/js/popper.min.js"></script>
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/cssX/check.css">
</head>
<body>
    <main style="min-height: 90vh; max-width: 100%;">

    	<?php 
            include "navbar.php";
        ?>
        <div style="height: 86px;"></div>

        <?php
        $idKH = $_SESSION['idKH'];
            // if (isset($_POST['saveCD'])) {
            //     $tenCD = $_POST['tenCD'];
            //     if (empty($tenCD)) {
            //         echo "<div class='check check_error'>Tên chủ đề không được để trống</div>";
            //       }else{
            //         $id = $_SESSION['idCD'];
            //         $sql = "UPDATE tb_chu_de SET ten_chu_de = '$tenCD' WHERE id = $id";
            //         mysqli_query($conn, $sql);
            //         echo "<div class='check'>Sửa thành công</div>";
            //       } 
            // } 

            // $query = getQuery('tb_chu_de', 'id', $_SESSION['idCD']);
            // $row = mysqli_fetch_array($query);
        ?>

    	<div class="d-flex justify-content-center mt-3">
            <form action="" method="POST" class="w-50">
                <h3>Thêm bài tập</h3>
                <div class="mb-3">
                  <label for="ten_bai_tap" class="form-label">Tên chủ đề</label>
                  <input type="text" class="form-control" id="ten_bai_tap" name="ten_bai_tap" placeholder="Nhập tên bài tập">
                </div>
                <div class="mb-3">
                  <label for="so_bai_nop" class="form-label">Số bài nộp tối đa</label>
                  <input type="number" class="form-control" id="so_bai_nop" name="so_bai_nop" placeholder="Nhập Số bài nộp tối đa">
                </div>
                <div class="mb-3">
                  <label for="han_nop" class="form-label">Hạn nộp</label>
                  <input type="datetime-local" class="form-control" id="han_nop" name="han_nop" placeholder="Nhập hạn nộp">
                </div>
                <div class="mb-3">
                  <label for="file_de_bai" class="form-label">Chọn file đề bài</label>
                  <input type="file" class="form-control" id="file_de_bai" name="file_de_bai">
                </div>
                <input type="submit" class="btn btn-success" name="saveBT" value="Lưu">
                <a href="ChuDeKhoaHoc.php?idKH=<?php echo $idKH; ?>" class="btn btn-success">Trở lại</a>

            </form>
        </div>
	</main>
    <?php include "footer.php"; ?>
</body>
</html>


