<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.css">
    <script type="text/javascript" src="assets/bootstrap/js/popper.min.js"></script>
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
	<style type="text/css">
	.navbar .text-nav:hover{
		text-shadow: 0px 2px 2px red;
		transform: translateY(-1px) translateX(1px);
		transition: font-size 0.1s;
	}
</style>
</head>
<body>
	  <div class="navbar text-uppercase py-0">
      <a class="nav-item nav-link p-2 text-success text-nav w-100" data-bs-toggle="collapse" style="font-weight: 700;" href="#collapseExample<?php  ?>" role="button" aria-expanded="false" aria-controls="collapseExample<?php  ?>">
        <i class="ri-file-ppt-line"></i> Tên Chủ Đề
      </a>
    </div>
    <div class="collapse navbar p-0" id="collapseExample<?php  ?>">
      <ul class="navbar-nav w-100">

        <li class="nav-item w-100 row my-1">
            <a class="col-8 nav-link text-success d-inline-block text-nav" style="padding-left: 28px; padding-top: 0;" href="<?php  ?>" target="if-content"><i class="ri-git-commit-line"></i>nd Chủ đề</a>
            <div class="col-4 p-0 d-flex justify-content-around align-items-center" style="">
                <div class="btn btn-success py-1">Sửa</div>
                <div class="btn btn-warning py-1">Xóa</div>
            </div>
        </li>

        <li class="nav-item"><a class="nav-link px-3 text-success text-nav" style="font-weight: 600;" href="#"><i class="ri-add-circle-line"></i>Tạo Khóa Học Mới</a></li>
      </ul>
    </div>


</body>
</html>