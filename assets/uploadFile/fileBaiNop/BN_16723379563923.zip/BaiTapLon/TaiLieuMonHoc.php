<?php 
	include 'connect.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Tài liệu môn học</title>
	<link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.css">
    <script type="text/javascript" src="assets/bootstrap/js/popper.min.js"></script>
	<script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
</head>
<body>
	<?php 
		include 'navbar.php';
		$idKH=$_SESSION['idKH'];
	 ?>
	 <div style="height: 86px;"></div>
	 <div id="action" style="margin: 20px 0 0 2%;">
            <a href="ChuDeKhoaHoc.php?idKH=<?php echo $idKH; ?>" class="btn btn-success">Trở lại</a>
            <a href="ThemHocLieu.php?idKH=<?php echo $idKH; ?>" class="btn btn-success">Thêm học liệu</a>
     </div>
		

</body>
</html>