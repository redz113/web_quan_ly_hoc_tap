<?php 
	include "Connect.php";

	$idBT = $_GET['idBT'];
	$idKH = $_SESSION['idKH'];

	xoa("tb_bai_tap", $idBT);                        //114 - function.php

	echo 
	"
		<script type='text/javascript'>
			alert('Xóa thành công!!!');
		</script>
	";

	header("refresh: 0.3; url =ChuDeKhoaHoc.php?idKH=$idKH");
?>
